DSD EC280 Assignment 2

Submitted By:
Anirudh BH (16EC105)
Manan Sharma (16EC118)

This assignment contains the PDF report, along with the source code for Q1,2,3.
The codes for each of Q1-3, along with their testbenchs and .wdb waveforms are present in the respective folders.

Individual Questions done
Q1,3,4,7 - Manan
Q2,3(testbech),5,6 - Anirudh