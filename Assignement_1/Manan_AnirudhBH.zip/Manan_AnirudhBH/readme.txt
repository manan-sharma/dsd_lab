Digital System Design(EC280) - Assignment 1
Submitted by Anirudh BH (16EC105) and Manan Sharma (16EC118)

